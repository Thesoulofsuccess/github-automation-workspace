import { useState, useEffect, useRef, useCallback } from "react";

/* ──────────────────────────────────────────────
   FONTS + GLOBAL STYLES
────────────────────────────────────────────── */
const GlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap');

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg:        #07090F;
      --bg2:       #0C0F1A;
      --bg3:       #111420;
      --border:    rgba(255,255,255,0.07);
      --border2:   rgba(255,255,255,0.12);
      --text:      #E8EDF5;
      --muted:     #4A5568;
      --muted2:    #718096;
      --cyan:      #00E5FF;
      --violet:    #9B6DFF;
      --emerald:   #00D68F;
      --amber:     #FFB830;
      --red:       #FF4D6A;
      --font-d:    'Outfit', sans-serif;
      --font-m:    'JetBrains Mono', monospace;
    }

    html, body, #root { height: 100%; background: var(--bg); }

    ::-webkit-scrollbar { width: 4px; height: 4px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }

    @keyframes fadeUp   { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:none; } }
    @keyframes pulse    { 0%,100% { opacity:1; } 50% { opacity:0.4; } }
    @keyframes spin     { to { transform: rotate(360deg); } }
    @keyframes scanline { 0% { transform: translateY(-100%); } 100% { transform: translateY(100vh); } }
    @keyframes shimmer  { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
    @keyframes blink    { 0%,100% { opacity:1; } 50% { opacity:0; } }
    @keyframes slideIn  { from { opacity:0; transform:translateX(-12px); } to { opacity:1; transform:none; } }
    @keyframes glow     { 0%,100% { box-shadow: 0 0 8px var(--cyan)44; } 50% { box-shadow: 0 0 20px var(--cyan)88; } }

    .fade-up   { animation: fadeUp 0.5s cubic-bezier(0.16,1,0.3,1) both; }
    .pulse-dot { animation: pulse 1.8s ease-in-out infinite; }
    .spinner   { animation: spin 0.8s linear infinite; }
    .blink     { animation: blink 1s step-end infinite; }
    .slide-in  { animation: slideIn 0.4s cubic-bezier(0.16,1,0.3,1) both; }
  `}</style>
);

/* ──────────────────────────────────────────────
   CONSTANTS
────────────────────────────────────────────── */
const DIMS = [
  { id: "fintech",   label: "FinTech / COO",      icon: "◈", color: "#00E5FF", glow: "#00E5FF33" },
  { id: "dev",       label: "Dev & Innovation",    icon: "⬡", color: "#9B6DFF", glow: "#9B6DFF33" },
  { id: "trading",   label: "Trading & Investing", icon: "◊", color: "#00D68F", glow: "#00D68F33" },
  { id: "marketing", label: "Marketing & People",  icon: "◉", color: "#FFB830", glow: "#FFB83033" },
];

const TABS = ["INTEL", "REPOS", "KNOWLEDGE BASE", "CHANGE LOG", "EXPORT"];

const USER_CONTEXT = `Vikash is a senior FinTech leader (COO/VP Ops level) at Redpin Payments in Mumbai with 21+ years experience in payments, operations, and compliance. He:
- Runs automation initiatives to reduce manual effort by 50-70% using Google Sheets, Apps Script, n8n
- Tracks NIFTY options trading (CE/PE frameworks, ITM strike logic, first 5-min candle analysis)
- Builds AI-powered SaaS products (Reel IQ - content intelligence for influencers)
- Is interested in marketing tools and helping people at scale
- Targets COO/Head of Payments roles at global FinTech firms
- Uses React, Python, Streamlit, n8n, Google Apps Script`;

const ANALYZE_PROMPT = `You are a senior intelligence analyst. Analyze this GitHub repository for Vikash.

USER CONTEXT:
${USER_CONTEXT}

Evaluate across 4 dimensions (score 0-100):
- fintech: payments infrastructure, ops automation, compliance/regulatory tech, team scaling tools
- dev: innovation level, AI/ML potential, architecture quality, builder/automation value  
- trading: market analysis, NIFTY/options tools, backtesting, data feeds, portfolio management
- marketing: audience tools, content automation, growth hacking, people-scale impact

Return ONLY valid JSON (no markdown, no backticks):
{
  "fintech": <number 0-100>,
  "dev": <number 0-100>,
  "trading": <number 0-100>,
  "marketing": <number 0-100>,
  "headline": "<one sharp sentence — what this repo IS and why it matters>",
  "vikash_use_case": "<exactly how Vikash uses this — be specific to his stack/context>",
  "watch_reason": "<what upcoming development makes this worth monitoring>",
  "tags": ["<tag1>","<tag2>","<tag3>"]
}`;

const IMPACT_PROMPT = `You are a senior intelligence analyst. A GitHub repository that Vikash watches just had new commits.

USER CONTEXT:
${USER_CONTEXT}

Analyze these new commits and explain their impact specifically for Vikash. Be direct and actionable.

Return ONLY valid JSON (no markdown, no backticks):
{
  "impact_title": "<8 words max — what changed>",
  "vikash_impact": "<2-3 sentences: what specifically this means for Vikash's work at Redpin / his trading / his dev projects / his marketing — be CONCRETE>",
  "action": "<one specific thing Vikash should do or explore now>",
  "urgency": "high|medium|low",
  "dimension": "fintech|dev|trading|marketing"
}`;

/* ──────────────────────────────────────────────
   GITHUB API HELPERS
────────────────────────────────────────────── */
function parseGitHubUrl(url) {
  const m = url.trim().match(/github\.com\/([^/\s]+)\/([^/?\s#]+)/);
  return m ? { owner: m[1], repo: m[2].replace(/\.git$/, "") } : null;
}

async function ghFetch(path) {
  const r = await fetch(`https://api.github.com${path}`);
  if (!r.ok) throw new Error(`GitHub API ${r.status}: ${path}`);
  return r.json();
}

async function fetchRepoData(owner, repo) {
  const [meta, commits] = await Promise.all([
    ghFetch(`/repos/${owner}/${repo}`),
    ghFetch(`/repos/${owner}/${repo}/commits?per_page=3`),
  ]);

  let readme = "";
  try {
    const rd = await ghFetch(`/repos/${owner}/${repo}/readme`);
    readme = atob(rd.content.replace(/\n/g, "")).slice(0, 4000);
  } catch {}

  return { meta, commits, readme };
}

/* ──────────────────────────────────────────────
   ANTHROPIC API HELPERS
────────────────────────────────────────────── */
async function callClaude(systemPrompt, userContent) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userContent }],
    }),
  });
  const data = await res.json();
  const text = data.content?.[0]?.text || "{}";
  return JSON.parse(text.replace(/```json|```/g, "").trim());
}

/* ──────────────────────────────────────────────
   PERSISTENT STORAGE HELPERS
────────────────────────────────────────────── */
async function storeGet(key, fallback = null) {
  try {
    const r = await window.storage.get(key);
    return r ? JSON.parse(r.value) : fallback;
  } catch { return fallback; }
}
async function storeSet(key, value) {
  try { await window.storage.set(key, JSON.stringify(value)); } catch {}
}

/* ──────────────────────────────────────────────
   SCORE RING
────────────────────────────────────────────── */
function ScoreRing({ score, size = 64, color = "#00E5FF" }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const dash = score != null ? circ * (score / 100) : 0;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4" />
      <circle
        cx={size/2} cy={size/2} r={r} fill="none"
        stroke={color} strokeWidth="4"
        strokeDasharray={`${dash} ${circ}`}
        strokeLinecap="round"
        style={{ transition: "stroke-dasharray 1.2s cubic-bezier(0.16,1,0.3,1)", filter: `drop-shadow(0 0 6px ${color}88)` }}
      />
      <text
        x="50%" y="50%" dominantBaseline="middle" textAnchor="middle"
        fill={score != null ? "#E8EDF5" : "#4A5568"}
        fontSize={size < 50 ? "11" : "14"}
        fontWeight="700"
        fontFamily="'JetBrains Mono'"
        style={{ transform: "rotate(90deg)", transformOrigin: "50% 50%" }}
      >
        {score != null ? score : "--"}
      </text>
    </svg>
  );
}

/* ──────────────────────────────────────────────
   SCORE BAR
────────────────────────────────────────────── */
function ScoreBar({ dim, score, show }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
        <span style={{ fontFamily: "var(--font-m)", fontSize: 10, color: dim.color, letterSpacing: "0.08em", opacity: 0.9 }}>
          {dim.icon} {dim.label}
        </span>
        <span style={{ fontFamily: "var(--font-m)", fontSize: 11, color: dim.color, fontWeight: 700 }}>
          {score ?? "—"}
        </span>
      </div>
      <div style={{ height: 3, background: "rgba(255,255,255,0.06)", borderRadius: 2, overflow: "hidden" }}>
        <div style={{
          height: "100%",
          width: show ? `${score ?? 0}%` : "0%",
          background: `linear-gradient(90deg, ${dim.color}66, ${dim.color})`,
          borderRadius: 2,
          transition: "width 1.1s cubic-bezier(0.16,1,0.3,1)",
          boxShadow: `0 0 10px ${dim.glow}`,
        }} />
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────
   URGENCY BADGE
────────────────────────────────────────────── */
function UrgencyBadge({ urgency }) {
  const map = { high: ["#FF4D6A", "HIGH"], medium: ["#FFB830", "MED"], low: ["#00D68F", "LOW"] };
  const [color, label] = map[urgency] || ["#4A5568", "—"];
  return (
    <span style={{
      background: color + "18", border: `1px solid ${color}44`,
      borderRadius: 4, padding: "2px 7px",
      fontFamily: "var(--font-m)", fontSize: 9, color, letterSpacing: "0.1em", fontWeight: 700,
    }}>{label}</span>
  );
}

/* ──────────────────────────────────────────────
   REPO CARD
────────────────────────────────────────────── */
function RepoCard({ entry, expanded, onToggle }) {
  const [barsVisible, setBarsVisible] = useState(false);
  useEffect(() => {
    if (entry.status === "done") {
      const t = setTimeout(() => setBarsVisible(true), 100);
      return () => clearTimeout(t);
    }
  }, [entry.status]);

  const totalScore = entry.analysis
    ? Math.round(DIMS.reduce((s, d) => s + (entry.analysis[d.id] || 0), 0) / DIMS.length)
    : null;

  const topDim = entry.analysis
    ? DIMS.reduce((a, d) => (entry.analysis[d.id] > entry.analysis[a.id] ? d : a), DIMS[0])
    : null;

  const hasChange = !!entry.latestImpact;

  return (
    <div
      className="fade-up"
      onClick={onToggle}
      style={{
        background: hasChange ? "rgba(255,184,48,0.03)" : "var(--bg2)",
        border: `1px solid ${hasChange ? "#FFB83030" : "var(--border)"}`,
        borderRadius: 14,
        padding: "18px 20px",
        marginBottom: 10,
        cursor: "pointer",
        transition: "border-color 0.3s, background 0.3s",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Glow accent top-left */}
      {topDim && (
        <div style={{
          position: "absolute", top: 0, left: 0,
          width: 3, height: "100%",
          background: `linear-gradient(180deg, ${topDim.color}, transparent)`,
          borderRadius: "14px 0 0 14px",
        }} />
      )}

      {/* Header row */}
      <div style={{ display: "flex", alignItems: "flex-start", gap: 14, marginBottom: 12 }}>
        <ScoreRing score={totalScore} size={56} color={topDim?.color || "#00E5FF"} />

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 3 }}>
            <span style={{
              fontFamily: "var(--font-d)", fontWeight: 700, fontSize: 15, color: "var(--text)",
              whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
            }}>
              {entry.owner}/{entry.repo}
            </span>

            {hasChange && (
              <span style={{
                background: "#FFB83018", border: "1px solid #FFB83055",
                borderRadius: 4, padding: "1px 7px",
                fontFamily: "var(--font-m)", fontSize: 9, color: "#FFB830",
                letterSpacing: "0.1em", fontWeight: 700,
                animation: "pulse 2s infinite",
              }}>● UPDATED</span>
            )}

            {entry.status === "fetching" && (
              <span style={{ color: "#9B6DFF", fontFamily: "var(--font-m)", fontSize: 10 }}>
                <span className="spinner" style={{ display: "inline-block", marginRight: 4 }}>◌</span>fetching…
              </span>
            )}
            {entry.status === "analyzing" && (
              <span style={{ color: "#00E5FF", fontFamily: "var(--font-m)", fontSize: 10, animation: "pulse 1s infinite" }}>
                ⬡ analyzing…
              </span>
            )}
            {entry.status === "error" && (
              <span style={{ color: "#FF4D6A", fontFamily: "var(--font-m)", fontSize: 10 }}>✕ {entry.error}</span>
            )}
          </div>

          {entry.meta && (
            <div style={{ fontFamily: "var(--font-m)", fontSize: 11, color: "var(--muted2)", display: "flex", gap: 12, flexWrap: "wrap" }}>
              <span>★ {(entry.meta.stargazers_count || 0).toLocaleString()}</span>
              <span>⑂ {entry.meta.forks_count || 0}</span>
              {entry.meta.language && <span style={{ color: "#4A5568" }}>// {entry.meta.language}</span>}
              {entry.meta.updated_at && (
                <span style={{ color: "#4A5568" }}>
                  {new Date(entry.meta.updated_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Headline */}
      {entry.analysis?.headline && (
        <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#94A3B8", lineHeight: 1.55, marginBottom: 14 }}>
          {entry.analysis.headline}
        </p>
      )}

      {/* Score bars */}
      {entry.analysis && (
        <div style={{ marginBottom: 12 }}>
          {DIMS.map(d => <ScoreBar key={d.id} dim={d} score={entry.analysis[d.id]} show={barsVisible} />)}
        </div>
      )}

      {/* Tags */}
      {entry.analysis?.tags?.length > 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: hasChange ? 12 : 0 }}>
          {entry.analysis.tags.map(t => (
            <span key={t} style={{
              background: "rgba(255,255,255,0.04)", border: "1px solid var(--border)",
              borderRadius: 4, padding: "2px 8px",
              fontFamily: "var(--font-m)", fontSize: 10, color: "var(--muted2)",
            }}>{t}</span>
          ))}
        </div>
      )}

      {/* Change impact banner */}
      {hasChange && entry.latestImpact && (
        <div style={{
          background: "rgba(255,184,48,0.06)", border: "1px solid #FFB83033",
          borderRadius: 8, padding: "10px 14px", marginTop: 2,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <span style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "#FFB830", letterSpacing: "0.1em" }}>
              ↯ WHAT THIS MEANS FOR YOU
            </span>
            <UrgencyBadge urgency={entry.latestImpact.urgency} />
          </div>
          <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#CBD5E1", lineHeight: 1.6, marginBottom: 6 }}>
            {entry.latestImpact.vikash_impact}
          </p>
          {entry.latestImpact.action && (
            <div style={{ display: "flex", alignItems: "flex-start", gap: 6 }}>
              <span style={{ color: "#00D68F", fontFamily: "var(--font-m)", fontSize: 10, marginTop: 2 }}>→</span>
              <span style={{ fontFamily: "var(--font-d)", fontSize: 12, color: "#00D68F", fontWeight: 500 }}>
                {entry.latestImpact.action}
              </span>
            </div>
          )}
        </div>
      )}

      {/* Expanded detail */}
      {expanded && entry.analysis && (
        <div style={{ borderTop: "1px solid var(--border)", marginTop: 14, paddingTop: 14 }} className="slide-in">
          {entry.analysis.vikash_use_case && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#00E5FF", letterSpacing: "0.12em", marginBottom: 6 }}>
                ◈ YOUR USE CASE
              </div>
              <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#94A3B8", lineHeight: 1.6 }}>
                {entry.analysis.vikash_use_case}
              </p>
            </div>
          )}
          {entry.analysis.watch_reason && (
            <div>
              <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#9B6DFF", letterSpacing: "0.12em", marginBottom: 6 }}>
                ⬡ WHY KEEP WATCHING
              </div>
              <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#94A3B8", lineHeight: 1.6 }}>
                {entry.analysis.watch_reason}
              </p>
            </div>
          )}
          {entry.latestCommit && (
            <div style={{ marginTop: 12, padding: "10px 12px", background: "var(--bg3)", borderRadius: 8 }}>
              <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#4A5568", letterSpacing: "0.1em", marginBottom: 4 }}>
                LATEST COMMIT
              </div>
              <div style={{ fontFamily: "var(--font-m)", fontSize: 11, color: "#64748B", lineHeight: 1.5 }}>
                {entry.latestCommit.message?.split("\n")[0]?.slice(0, 80)}
              </div>
              <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "#4A5568", marginTop: 4 }}>
                {entry.latestCommit.sha?.slice(0, 7)} · {entry.latestCommit.date ? new Date(entry.latestCommit.date).toLocaleString("en-IN") : ""}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ──────────────────────────────────────────────
   INTEL TAB — DASHBOARD OVERVIEW
────────────────────────────────────────────── */
function IntelTab({ repos, countdown, pollInterval, onPollNow, lastPolled }) {
  const done = repos.filter(r => r.status === "done");
  const changed = repos.filter(r => r.latestImpact);

  const avgByDim = DIMS.map(d => ({
    ...d,
    avg: done.length
      ? Math.round(done.reduce((s, r) => s + (r.analysis?.[d.id] || 0), 0) / done.length)
      : null,
  }));

  const topRepo = done.length
    ? done.reduce((a, r) => {
        const sa = DIMS.reduce((s, d) => s + (a.analysis?.[d.id] || 0), 0);
        const sr = DIMS.reduce((s, d) => s + (r.analysis?.[d.id] || 0), 0);
        return sr > sa ? r : a;
      }, done[0])
    : null;

  const minutesLeft = Math.floor(countdown / 60);
  const secsLeft = countdown % 60;

  return (
    <div>
      {/* Status bar */}
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 10, marginBottom: 20,
      }}>
        {[
          { label: "REPOS TRACKED", value: repos.length, color: "#00E5FF" },
          { label: "ANALYZED", value: done.length, color: "#9B6DFF" },
          { label: "UPDATES PENDING", value: changed.length, color: changed.length ? "#FFB830" : "#4A5568" },
          { label: "NEXT POLL", value: repos.length ? `${minutesLeft}:${String(secsLeft).padStart(2, "0")}` : "—", color: "#00D68F" },
        ].map(s => (
          <div key={s.label} style={{
            background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 10, padding: "14px 16px",
          }}>
            <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "var(--muted)", letterSpacing: "0.1em", marginBottom: 6 }}>
              {s.label}
            </div>
            <div style={{ fontFamily: "var(--font-d)", fontWeight: 800, fontSize: 28, color: s.color }}>
              {s.value}
            </div>
          </div>
        ))}
      </div>

      {/* Dimension averages */}
      {done.length > 0 && (
        <div style={{ background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 12, padding: "18px 20px", marginBottom: 20 }}>
          <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "var(--muted)", letterSpacing: "0.12em", marginBottom: 14 }}>
            PORTFOLIO FIT AVERAGES
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
            {avgByDim.map(d => (
              <div key={d.id}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                  <ScoreRing score={d.avg} size={44} color={d.color} />
                  <div>
                    <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: d.color, letterSpacing: "0.08em" }}>
                      {d.icon} {d.label}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top pick */}
      {topRepo && (
        <div style={{
          background: "linear-gradient(135deg, rgba(0,229,255,0.04), rgba(155,109,255,0.04))",
          border: "1px solid rgba(0,229,255,0.15)", borderRadius: 12, padding: "18px 20px", marginBottom: 20,
        }}>
          <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#00E5FF", letterSpacing: "0.12em", marginBottom: 8 }}>
            ◈ HIGHEST FIT REPO
          </div>
          <div style={{ fontFamily: "var(--font-d)", fontWeight: 700, fontSize: 16, color: "var(--text)", marginBottom: 4 }}>
            {topRepo.owner}/{topRepo.repo}
          </div>
          <div style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#64748B" }}>
            {topRepo.analysis?.headline}
          </div>
        </div>
      )}

      {/* Active alerts */}
      {changed.length > 0 && (
        <div>
          <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "#FFB830", letterSpacing: "0.12em", marginBottom: 10 }}>
            ↯ ACTIVE IMPACT ALERTS
          </div>
          {changed.map(r => (
            <div key={r.id} style={{
              background: "rgba(255,184,48,0.04)", border: "1px solid #FFB83030",
              borderRadius: 10, padding: "12px 16px", marginBottom: 8,
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <span style={{ fontFamily: "var(--font-d)", fontWeight: 600, fontSize: 13, color: "var(--text)" }}>
                  {r.owner}/{r.repo}
                </span>
                <UrgencyBadge urgency={r.latestImpact?.urgency} />
              </div>
              <p style={{ fontFamily: "var(--font-d)", fontSize: 12, color: "#94A3B8", lineHeight: 1.5 }}>
                {r.latestImpact?.vikash_impact}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* Poll control */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 20 }}>
        <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "var(--muted)" }}>
          {lastPolled ? `Last polled: ${new Date(lastPolled).toLocaleTimeString("en-IN")}` : "Not yet polled"}
        </div>
        <button
          onClick={onPollNow}
          style={{
            background: "rgba(0,229,255,0.08)", border: "1px solid rgba(0,229,255,0.2)",
            borderRadius: 8, padding: "8px 16px",
            fontFamily: "var(--font-m)", fontSize: 11, color: "#00E5FF", cursor: "pointer",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => e.target.style.background = "rgba(0,229,255,0.14)"}
          onMouseLeave={e => e.target.style.background = "rgba(0,229,255,0.08)"}
        >
          ↺ POLL NOW
        </button>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────
   KNOWLEDGE BASE TAB
────────────────────────────────────────────── */
function KnowledgeBaseTab({ repos }) {
  const [selected, setSelected] = useState(null);
  const done = repos.filter(r => r.status === "done" && r.readme);

  return (
    <div style={{ display: "grid", gridTemplateColumns: done.length ? "200px 1fr" : "1fr", gap: 12, minHeight: 300 }}>
      {done.length === 0 ? (
        <div style={{ textAlign: "center", padding: 40, color: "var(--muted)" }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>⬡</div>
          <div style={{ fontFamily: "var(--font-m)", fontSize: 12 }}>Analyze repos to build knowledge base</div>
        </div>
      ) : (
        <>
          <div>
            {done.map(r => (
              <div
                key={r.id}
                onClick={() => setSelected(r.id)}
                style={{
                  padding: "10px 12px", borderRadius: 8, marginBottom: 6, cursor: "pointer",
                  background: selected === r.id ? "rgba(0,229,255,0.08)" : "transparent",
                  border: `1px solid ${selected === r.id ? "rgba(0,229,255,0.2)" : "transparent"}`,
                  transition: "all 0.2s",
                }}
              >
                <div style={{ fontFamily: "var(--font-d)", fontWeight: 600, fontSize: 12, color: "var(--text)", marginBottom: 2 }}>
                  {r.repo}
                </div>
                <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "var(--muted)" }}>
                  {r.owner}
                </div>
              </div>
            ))}
          </div>
          <div style={{
            background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: 12,
            padding: "18px 20px", overflow: "auto", maxHeight: 480,
          }}>
            {selected ? (() => {
              const r = repos.find(x => x.id === selected);
              return r ? (
                <>
                  <div style={{ fontFamily: "var(--font-d)", fontWeight: 700, fontSize: 16, color: "var(--text)", marginBottom: 4 }}>
                    {r.owner}/{r.repo}
                  </div>
                  {r.meta?.description && (
                    <div style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#64748B", marginBottom: 16 }}>
                      {r.meta.description}
                    </div>
                  )}
                  {r.analysis?.vikash_use_case && (
                    <div style={{ background: "rgba(0,229,255,0.05)", border: "1px solid rgba(0,229,255,0.12)", borderRadius: 8, padding: "12px 14px", marginBottom: 16 }}>
                      <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#00E5FF", letterSpacing: "0.1em", marginBottom: 6 }}>YOUR USE CASE</div>
                      <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#94A3B8", lineHeight: 1.6 }}>{r.analysis.vikash_use_case}</p>
                    </div>
                  )}
                  <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "var(--muted)", letterSpacing: "0.1em", marginBottom: 8 }}>
                    README EXTRACT
                  </div>
                  <pre style={{
                    fontFamily: "var(--font-m)", fontSize: 11, color: "#64748B",
                    whiteSpace: "pre-wrap", lineHeight: 1.7, background: "var(--bg3)",
                    borderRadius: 8, padding: "14px 16px",
                  }}>
                    {r.readme?.slice(0, 2000) || "No README available"}
                  </pre>
                </>
              ) : null;
            })() : (
              <div style={{ color: "var(--muted)", fontFamily: "var(--font-m)", fontSize: 12, textAlign: "center", paddingTop: 40 }}>
                ← Select a repo
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

/* ──────────────────────────────────────────────
   CHANGE LOG TAB
────────────────────────────────────────────── */
function ChangeLogTab({ changelog }) {
  if (changelog.length === 0) return (
    <div style={{ textAlign: "center", padding: 60, color: "var(--muted)" }}>
      <div style={{ fontSize: 32, marginBottom: 8 }}>◊</div>
      <div style={{ fontFamily: "var(--font-m)", fontSize: 12 }}>Change log will appear once repos are polled</div>
    </div>
  );

  return (
    <div>
      {changelog.slice().reverse().map((c, i) => {
        const dim = DIMS.find(d => d.id === c.dimension) || DIMS[0];
        return (
          <div key={i} className="fade-up" style={{
            background: "var(--bg2)", border: "1px solid var(--border)",
            borderRadius: 12, padding: "16px 18px", marginBottom: 10,
            borderLeft: `3px solid ${dim.color}`,
            animationDelay: `${i * 0.04}s`,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
              <div>
                <div style={{ fontFamily: "var(--font-d)", fontWeight: 700, fontSize: 14, color: "var(--text)", marginBottom: 2 }}>
                  {c.repo}
                </div>
                <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: dim.color }}>
                  {dim.icon} {c.impact_title}
                </div>
              </div>
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <UrgencyBadge urgency={c.urgency} />
                <span style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "var(--muted)" }}>
                  {new Date(c.timestamp).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            </div>
            <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "#94A3B8", lineHeight: 1.6, marginBottom: 8 }}>
              {c.vikash_impact}
            </p>
            {c.action && (
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <span style={{ color: "#00D68F", fontFamily: "var(--font-m)", fontSize: 11 }}>→</span>
                <span style={{ fontFamily: "var(--font-d)", fontSize: 12, color: "#00D68F", fontWeight: 500 }}>{c.action}</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ──────────────────────────────────────────────
   EXPORT TAB — CLAUDE.MD
────────────────────────────────────────────── */
function ExportTab({ repos }) {
  const done = repos.filter(r => r.status === "done");

  const claudeMd = `# GitHub Intel Station — CLAUDE.md
> Auto-generated knowledge base for Claude Code sessions
> Owner: Vikash | Redpin Payments | Mumbai
> Last updated: ${new Date().toLocaleString("en-IN")}

## Project Context

Vikash is a senior FinTech leader (COO/VP Ops) at Redpin Payments with 21+ years experience.
Active across: payments automation, NIFTY options trading, AI SaaS (Reel IQ), growth marketing.

## Tracked Repository Intelligence

${done.map(r => `### ${r.owner}/${r.repo}
- **URL**: https://github.com/${r.owner}/${r.repo}
- **Description**: ${r.meta?.description || "N/A"}
- **Language**: ${r.meta?.language || "N/A"} | **Stars**: ${r.meta?.stargazers_count || 0}
- **Headline**: ${r.analysis?.headline || "N/A"}
- **Scores**: FinTech ${r.analysis?.fintech || 0}/100 · Dev ${r.analysis?.dev || 0}/100 · Trading ${r.analysis?.trading || 0}/100 · Marketing ${r.analysis?.marketing || 0}/100
- **Vikash Use Case**: ${r.analysis?.vikash_use_case || "N/A"}
- **Watch Reason**: ${r.analysis?.watch_reason || "N/A"}
- **Tags**: ${r.analysis?.tags?.join(", ") || "N/A"}
`).join("\n")}

## Development Standards

\`\`\`
DESIGN: Precision Minimal (Linear/Vercel/Raycast inspired)
FONTS:  Plus Jakarta Sans + JetBrains Mono
ACCENT: Electric Indigo #6366F1
STACK:  React + Streamlit + n8n + Google Apps Script
TEST:   Local first → screenshot loop → GitHub → Vercel
\`\`\`

## Rules for Claude Code

1. Always read this CLAUDE.md at session start
2. Reference repository intelligence above when recommending tools/libraries
3. Prioritize high-scoring repos in the relevant dimension for the current task
4. Surface change log items that affect the current work context
5. When building for Redpin: reference fintech-scored repos first
6. When building trading tools: reference trading-scored repos first

## Auto-Update Workflow

\`\`\`yaml
# .github/workflows/monitor.yml
name: GitHub Intel Monitor
on:
  schedule:
    - cron: '0 */6 * * *'  # Every 6 hours
  workflow_dispatch:

jobs:
  poll:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Poll starred repos
        run: node scripts/poll.js
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
          ANTHROPIC_API_KEY: \${{ secrets.ANTHROPIC_API_KEY }}
      - name: Commit updates
        run: |
          git config --local user.email "action@github.com"
          git config --local user.name "GitHub Action"
          git add docs/knowledge-base/
          git diff --staged --quiet || git commit -m "chore: auto-update knowledge base"
          git push
\`\`\`

## Directory Structure

\`\`\`
github-intel-station/
├── CLAUDE.md                    ← This file (auto-regenerated)
├── README.md
├── src/
│   └── GitHubIntelStation.jsx   ← Main artifact
├── scripts/
│   └── poll.js                  ← Node.js change detection
├── docs/
│   └── knowledge-base/
│       └── repos.json           ← Structured repo intelligence
└── .github/
    └── workflows/
        └── monitor.yml          ← Auto-update pipeline
\`\`\`
`;

  const copy = () => {
    navigator.clipboard.writeText(claudeMd);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div>
          <div style={{ fontFamily: "var(--font-d)", fontWeight: 700, fontSize: 16, color: "var(--text)", marginBottom: 2 }}>
            CLAUDE.md Export
          </div>
          <div style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "var(--muted)" }}>
            Drop into your GitHub repo root — Claude Code reads this at session start
          </div>
        </div>
        <button
          onClick={copy}
          style={{
            background: "rgba(155,109,255,0.1)", border: "1px solid rgba(155,109,255,0.25)",
            borderRadius: 8, padding: "8px 16px",
            fontFamily: "var(--font-m)", fontSize: 11, color: "#9B6DFF", cursor: "pointer",
          }}
        >
          ⧉ COPY
        </button>
      </div>
      <pre style={{
        fontFamily: "var(--font-m)", fontSize: 11, color: "#64748B",
        whiteSpace: "pre-wrap", lineHeight: 1.75,
        background: "var(--bg2)", border: "1px solid var(--border)",
        borderRadius: 12, padding: "18px 20px", overflow: "auto", maxHeight: 520,
      }}>
        {claudeMd}
      </pre>
    </div>
  );
}

/* ──────────────────────────────────────────────
   MAIN APP
────────────────────────────────────────────── */
export default function GitHubIntelStation() {
  const [tab, setTab] = useState(0);
  const [repos, setRepos] = useState([]);
  const [changelog, setChangelog] = useState([]);
  const [input, setInput] = useState("");
  const [expanded, setExpanded] = useState(null);
  const [countdown, setCountdown] = useState(1800); // 30 min
  const [lastPolled, setLastPolled] = useState(null);
  const [isPolling, setIsPolling] = useState(false);
  const pollInterval = 1800; // seconds

  /* Load persisted data */
  useEffect(() => {
    (async () => {
      const savedRepos = await storeGet("gis:repos", []);
      const savedLog   = await storeGet("gis:changelog", []);
      if (savedRepos.length) setRepos(savedRepos);
      if (savedLog.length)   setChangelog(savedLog);
    })();
  }, []);

  /* Persist repos + changelog */
  useEffect(() => { storeSet("gis:repos", repos); }, [repos]);
  useEffect(() => { storeSet("gis:changelog", changelog); }, [changelog]);

  /* Countdown timer */
  useEffect(() => {
    const t = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) {
          pollAll();
          return pollInterval;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [repos]);

  /* ── Analyze a single repo ── */
  const analyzeRepo = useCallback(async (id) => {
    setRepos(prev => prev.map(r => r.id === id ? { ...r, status: "fetching" } : r));
    try {
      const repo = repos.find(r => r.id === id) || await new Promise(res => setRepos(prev => { res(prev.find(r => r.id === id)); return prev; }));
      const { meta, commits, readme } = await fetchRepoData(repo.owner, repo.repo);

      setRepos(prev => prev.map(r => r.id === id ? { ...r, status: "analyzing", meta, readme, latestCommit: commits[0]?.commit ? { sha: commits[0].sha, message: commits[0].commit.message, date: commits[0].commit.committer.date } : null } : r));

      const prompt = `Repository: ${meta.full_name}
Description: ${meta.description || "None"}
Stars: ${meta.stargazers_count} | Forks: ${meta.forks_count} | Language: ${meta.language || "N/A"}
Topics: ${(meta.topics || []).join(", ") || "none"}
Recent commits: ${commits.slice(0, 3).map(c => c.commit?.message?.split("\n")[0]).join(" | ")}
README (excerpt):
${readme.slice(0, 3000)}`;

      const analysis = await callClaude(ANALYZE_PROMPT, prompt);
      setRepos(prev => prev.map(r => r.id === id ? { ...r, status: "done", analysis } : r));
    } catch (err) {
      setRepos(prev => prev.map(r => r.id === id ? { ...r, status: "error", error: err.message.slice(0, 40) } : r));
    }
  }, [repos]);

  /* ── Add repos from URL input ── */
  const addRepos = useCallback(async () => {
    const lines = input.split(/[\n,]+/).map(l => l.trim()).filter(Boolean);
    const parsed = lines.map(parseGitHubUrl).filter(Boolean);
    if (!parsed.length) return;

    const newEntries = parsed
      .filter(p => !repos.find(r => r.owner === p.owner && r.repo === p.repo))
      .map(p => ({
        id: `${p.owner}/${p.repo}`,
        owner: p.owner,
        repo: p.repo,
        status: "pending",
        meta: null,
        analysis: null,
        readme: "",
        latestCommit: null,
        latestImpact: null,
        lastSeenSha: null,
      }));

    if (!newEntries.length) { setInput(""); return; }
    setRepos(prev => [...prev, ...newEntries]);
    setInput("");

    // Analyze each sequentially
    for (const entry of newEntries) {
      await new Promise(res => setTimeout(res, 200));
      setRepos(prev => prev.map(r => r.id === entry.id ? { ...r, status: "fetching" } : r));
      try {
        const { meta, commits, readme } = await fetchRepoData(entry.owner, entry.repo);
        setRepos(prev => prev.map(r => r.id === entry.id ? {
          ...r, status: "analyzing", meta, readme,
          lastSeenSha: commits[0]?.sha || null,
          latestCommit: commits[0]?.commit ? { sha: commits[0].sha, message: commits[0].commit.message, date: commits[0].commit.committer.date } : null,
        } : r));

        const prompt = `Repository: ${meta.full_name}
Description: ${meta.description || "None"}
Stars: ${meta.stargazers_count} | Language: ${meta.language || "N/A"}
Topics: ${(meta.topics || []).join(", ") || "none"}
Recent commits: ${commits.slice(0, 3).map(c => c.commit?.message?.split("\n")[0]).join(" | ")}
README:
${readme.slice(0, 3000)}`;

        const analysis = await callClaude(ANALYZE_PROMPT, prompt);
        setRepos(prev => prev.map(r => r.id === entry.id ? { ...r, status: "done", analysis } : r));
      } catch (err) {
        setRepos(prev => prev.map(r => r.id === entry.id ? { ...r, status: "error", error: err.message.slice(0, 40) } : r));
      }
    }
  }, [input, repos]);

  /* ── Poll all repos for changes ── */
  const pollAll = useCallback(async () => {
    if (isPolling) return;
    setIsPolling(true);
    setLastPolled(Date.now());

    for (const repo of repos.filter(r => r.status === "done")) {
      try {
        const { commits } = await fetchRepoData(repo.owner, repo.repo);
        const newSha = commits[0]?.sha;
        if (!newSha || newSha === repo.lastSeenSha) continue;

        // New commits detected — get impact analysis
        const commitMessages = commits
          .filter((_, i) => i < 5)
          .map(c => `- ${c.commit?.message?.split("\n")[0]}`)
          .join("\n");

        const prompt = `Repository: ${repo.owner}/${repo.repo}
Previous known state: ${repo.lastSeenSha?.slice(0, 7) || "first check"}
New commits detected:
${commitMessages}
Repository context: ${repo.meta?.description || ""}
Vikash's use case for this repo: ${repo.analysis?.vikash_use_case || ""}`;

        const impact = await callClaude(IMPACT_PROMPT, prompt);
        const logEntry = {
          repo: `${repo.owner}/${repo.repo}`,
          timestamp: Date.now(),
          sha: newSha,
          ...impact,
        };

        setRepos(prev => prev.map(r =>
          r.id === repo.id ? { ...r, lastSeenSha: newSha, latestImpact: impact } : r
        ));
        setChangelog(prev => [...prev, logEntry]);
      } catch {}
    }
    setIsPolling(false);
  }, [repos, isPolling]);

  const removeRepo = (id) => setRepos(prev => prev.filter(r => r.id !== id));
  const clearImpact = (id) => setRepos(prev => prev.map(r => r.id === id ? { ...r, latestImpact: null } : r));
  const alertCount = repos.filter(r => r.latestImpact).length;

  /* ──────────────────────────────────────────
     RENDER
  ────────────────────────────────────────── */
  return (
    <div style={{
      minHeight: "100vh",
      background: "var(--bg)",
      fontFamily: "var(--font-d)",
      color: "var(--text)",
      position: "relative",
      overflow: "hidden",
    }}>
      <GlobalStyles />

      {/* Grid background */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: `
          linear-gradient(rgba(0,229,255,0.02) 1px, transparent 1px),
          linear-gradient(90deg, rgba(0,229,255,0.02) 1px, transparent 1px)
        `,
        backgroundSize: "48px 48px",
      }} />

      {/* Glow orbs */}
      <div style={{ position: "fixed", top: -120, left: -80, width: 360, height: 360, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,229,255,0.06) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 }} />
      <div style={{ position: "fixed", bottom: -80, right: -60, width: 280, height: 280, borderRadius: "50%", background: "radial-gradient(circle, rgba(155,109,255,0.06) 0%, transparent 70%)", pointerEvents: "none", zIndex: 0 }} />

      {/* Main container */}
      <div style={{ position: "relative", zIndex: 1, maxWidth: 860, margin: "0 auto", padding: "0 16px 40px" }}>

        {/* ── HEADER ── */}
        <div style={{ padding: "28px 0 24px", borderBottom: "1px solid var(--border)", marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                <span style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "#00E5FF", letterSpacing: "0.15em" }}>
                  ◈ GITHUB INTEL STATION
                </span>
                <span style={{ width: 1, height: 10, background: "var(--border2)" }} />
                <span style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "var(--muted)", letterSpacing: "0.08em" }}>
                  v1.0 · VIKASH
                </span>
                {isPolling && (
                  <>
                    <span style={{ width: 1, height: 10, background: "var(--border2)" }} />
                    <span style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "#FFB830", animation: "pulse 1s infinite" }}>
                      ● POLLING
                    </span>
                  </>
                )}
              </div>
              <h1 style={{
                fontFamily: "var(--font-d)", fontWeight: 900, fontSize: "clamp(22px, 5vw, 32px)",
                color: "var(--text)", letterSpacing: "-0.03em", lineHeight: 1.1,
              }}>
                Repo Intelligence <span style={{ color: "#00E5FF" }}>+</span> Impact
              </h1>
              <p style={{ fontFamily: "var(--font-d)", fontSize: 13, color: "var(--muted2)", marginTop: 6 }}>
                Multi-agent fit scoring · Live change detection · Personalized impact briefings
              </p>
            </div>
            {alertCount > 0 && (
              <div style={{
                background: "rgba(255,184,48,0.1)", border: "1px solid #FFB83044",
                borderRadius: 10, padding: "10px 16px", textAlign: "center", flexShrink: 0,
                animation: "glow 2s infinite",
              }}>
                <div style={{ fontFamily: "var(--font-d)", fontWeight: 800, fontSize: 24, color: "#FFB830" }}>
                  {alertCount}
                </div>
                <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#FFB830", letterSpacing: "0.1em" }}>
                  ALERTS
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ── URL INPUT ── */}
        <div style={{
          background: "var(--bg2)", border: "1px solid var(--border2)",
          borderRadius: 12, padding: "16px 18px", marginBottom: 20,
        }}>
          <div style={{ fontFamily: "var(--font-m)", fontSize: 9, color: "#00E5FF", letterSpacing: "0.12em", marginBottom: 10 }}>
            ◈ ADD GITHUB REPOS — PASTE URLS (ONE PER LINE OR COMMA-SEPARATED)
          </div>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && e.metaKey && addRepos()}
            placeholder="https://github.com/owner/repo&#10;https://github.com/owner/repo2"
            style={{
              width: "100%", minHeight: 72, background: "var(--bg3)",
              border: "1px solid var(--border)", borderRadius: 8, padding: "10px 12px",
              fontFamily: "var(--font-m)", fontSize: 12, color: "var(--text)",
              resize: "vertical", outline: "none", lineHeight: 1.6,
            }}
          />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
            <span style={{ fontFamily: "var(--font-m)", fontSize: 10, color: "var(--muted)" }}>
              ⌘↵ to submit · Auto-poll every 30 min
            </span>
            <button
              onClick={addRepos}
              disabled={!input.trim()}
              style={{
                background: input.trim() ? "rgba(0,229,255,0.1)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${input.trim() ? "rgba(0,229,255,0.25)" : "var(--border)"}`,
                borderRadius: 8, padding: "8px 20px",
                fontFamily: "var(--font-m)", fontSize: 11,
                color: input.trim() ? "#00E5FF" : "var(--muted)",
                cursor: input.trim() ? "pointer" : "default",
                transition: "all 0.2s",
              }}
            >
              ANALYZE →
            </button>
          </div>
        </div>

        {/* ── TABS ── */}
        <div style={{ display: "flex", gap: 2, marginBottom: 20, borderBottom: "1px solid var(--border)", paddingBottom: 0 }}>
          {TABS.map((t, i) => (
            <button
              key={t}
              onClick={() => setTab(i)}
              style={{
                background: "none", border: "none", borderBottom: `2px solid ${tab === i ? "#00E5FF" : "transparent"}`,
                padding: "10px 14px", marginBottom: -1,
                fontFamily: "var(--font-m)", fontSize: 10, letterSpacing: "0.1em",
                color: tab === i ? "#00E5FF" : "var(--muted)",
                cursor: "pointer", transition: "color 0.2s",
                position: "relative",
              }}
            >
              {t}
              {t === "CHANGE LOG" && changelog.length > 0 && (
                <span style={{
                  position: "absolute", top: 6, right: 4,
                  background: "#FFB830", borderRadius: "50%",
                  width: 6, height: 6, display: "block",
                }} />
              )}
            </button>
          ))}
        </div>

        {/* ── TAB CONTENT ── */}
        {tab === 0 && (
          <IntelTab repos={repos} countdown={countdown} pollInterval={pollInterval} onPollNow={pollAll} lastPolled={lastPolled} />
        )}

        {tab === 1 && (
          <div>
            {repos.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 0", color: "var(--muted)" }}>
                <div style={{ fontSize: 40, marginBottom: 12, opacity: 0.3 }}>⬡</div>
                <div style={{ fontFamily: "var(--font-m)", fontSize: 12, marginBottom: 4 }}>No repos yet</div>
                <div style={{ fontFamily: "var(--font-d)", fontSize: 13 }}>Paste GitHub URLs above to begin intelligence analysis</div>
              </div>
            ) : repos.map(r => (
              <div key={r.id} style={{ position: "relative" }}>
                <RepoCard
                  entry={r}
                  expanded={expanded === r.id}
                  onToggle={() => setExpanded(expanded === r.id ? null : r.id)}
                />
                {/* Remove + dismiss buttons */}
                <div style={{ position: "absolute", top: 18, right: 18, display: "flex", gap: 6 }}>
                  {r.latestImpact && (
                    <button
                      onClick={e => { e.stopPropagation(); clearImpact(r.id); }}
                      title="Dismiss alert"
                      style={{ background: "rgba(255,184,48,0.1)", border: "1px solid #FFB83033", borderRadius: 6, padding: "2px 7px", fontFamily: "var(--font-m)", fontSize: 10, color: "#FFB830", cursor: "pointer" }}
                    >✕ dismiss</button>
                  )}
                  <button
                    onClick={e => { e.stopPropagation(); removeRepo(r.id); }}
                    title="Remove repo"
                    style={{ background: "rgba(255,77,106,0.08)", border: "1px solid rgba(255,77,106,0.15)", borderRadius: 6, padding: "2px 7px", fontFamily: "var(--font-m)", fontSize: 10, color: "#FF4D6A", cursor: "pointer" }}
                  >✕</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 2 && <KnowledgeBaseTab repos={repos} />}
        {tab === 3 && <ChangeLogTab changelog={changelog} />}
        {tab === 4 && <ExportTab repos={repos} />}
      </div>
    </div>
  );
}
