import { useState, useCallback } from "react";

const DIMENSIONS = [
  {
    id: "fintech",
    label: "FinTech / COO",
    icon: "◈",
    color: "#00D4FF",
    desc: "Relevance to payments, operations, compliance, scaling teams",
  },
  {
    id: "dev",
    label: "Dev & Innovation",
    icon: "⬡",
    color: "#7C3AED",
    desc: "Forward-looking tech, architecture patterns, build value",
  },
  {
    id: "trading",
    label: "Trading & Investing",
    icon: "◊",
    color: "#10B981",
    desc: "Tools, frameworks, signals relevant to markets and analysis",
  },
  {
    id: "marketing",
    label: "Marketing & People",
    icon: "◉",
    color: "#F59E0B",
    desc: "Helps educate, grow audiences, or assist people at scale",
  },
];

function parseGitHubUrl(url) {
  try