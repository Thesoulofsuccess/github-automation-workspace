# CLAUDE.md — github-intel-station
> Read this file at the start of every Claude Code session.

## What This Project Is

**GitHub Intel Station** — A full-stack intelligence layer that:
1. Pulls README + metadata from curated GitHub repos into a live knowledge base
2. Runs multi-agent AI scoring across 4 dimensions (FinTech, Dev, Trading, Marketing)
3. Polls repos every 30 min for new commits and generates personalized impact briefings
4. Exports structured `CLAUDE.md` snapshots for use across Claude Code sessions

**Owner**: Vikash | Redpin Payments | Mumbai, India
**Stack**: React (artifact) + GitHub API + Anthropic API + window.storage (persistence)

---

## Owner Context (Always Apply)

Vikash is a senior FinTech leader targeting COO/VP Operations/Head of Payments roles.

| Domain         | Context |
|----------------|---------|
| **Day job**    | Redpin Payments — payments ops, compliance, ACH/NACHA, JP Morgan Chase + Cross River Bank |
| **Automation** | Google Forms + Sheets + Apps Script + n8n; targeting 50–70% manual effort reduction |
| **Trading**    | NIFTY options — CE/PE framework, first 5-min candle, ITM strike logic |
| **SaaS build** | Reel IQ — AI content intelligence for influencers (Streamlit, Python) |
| **Marketing**  | Audience tools, LinkedIn automation, n8n dual-approval workflow |
| **Location**   | Mumbai, India |

---

## Project Structure

```
github-intel-station/
├── CLAUDE.md                        ← This file (update after each session)
├── README.md                        ← Auto-generated — do not edit manually
├── package.json
├── src/
│   └── GitHubIntelStation.jsx       ← Main React artifact
├── scripts/
│   ├── poll.js                      ← Node.js poller (runs in GitHub Actions)
│   └── export-kb.js                 ← Exports knowledge base to docs/
├── docs/
│   └── knowledge-base/
│       ├── repos.json               ← Structured intelligence per repo
│       └── changelog.json           ← Change log with impact briefings
└── .github/
    └── workflows/
        └── monitor.yml              ← Auto-poll every 6 hours
```

---

## Design System (Non-Negotiable)

```
Aesthetic:    Precision Minimal — dark intelligence terminal
Background:   #07090F (primary), #0C0F1A (surface), #111420 (elevated)
Accent:       #00E5FF (cyan / primary action)
Dimensions:   #00E5FF fintech · #9B6DFF dev · #00D68F trading · #FFB830 marketing
Fonts:        Outfit (display) + JetBrains Mono (data/code)
Borders:      rgba(255,255,255,0.07) default · rgba(255,255,255,0.12) hover
Motion:       fadeUp 0.5s · ScoreBar fill 1.1s cubic-bezier(0.16,1,0.3,1)
```

---

## 4 Scoring Dimensions

| ID          | Icon | Color     | What It Measures |
|-------------|------|-----------|-----------------|
| `fintech`   | ◈    | `#00E5FF` | Payments, ops automation, compliance/reg tech, team scaling |
| `dev`       | ⬡    | `#9B6DFF` | Innovation, AI/ML, architecture quality, builder value |
| `trading`   | ◊    | `#00D68F` | Market analysis, NIFTY/options, backtesting, data feeds |
| `marketing` | ◉    | `#FFB830` | Audience tools, content automation, people-scale impact |

---

## GitHub Actions Auto-Monitor

```yaml
# .github/workflows/monitor.yml
name: GitHub Intel Monitor
on:
  schedule:
    - cron: '0 */6 * * *'   # Every 6 hours
  workflow_dispatch:

jobs:
  poll:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: '20'

      - name: Install deps
        run: npm ci

      - name: Poll repos + generate impact briefings
        run: node scripts/poll.js
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

      - name: Commit knowledge base updates
        run: |
          git config --local user.email "intel-bot@github.com"
          git config --local user.name "Intel Bot"
          git add docs/knowledge-base/
          git diff --staged --quiet || git commit -m "chore(kb): auto-update $(date +'%Y-%m-%d %H:%M')"
          git push
```

---

## scripts/poll.js — Node Poller Template

```javascript
// scripts/poll.js
const { Anthropic } = require('@anthropic-ai/sdk');
const fs = require('fs');

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const KB_PATH = './docs/knowledge-base/repos.json';
const LOG_PATH = './docs/knowledge-base/changelog.json';

async function pollRepo(entry) {
  const res = await fetch(
    `https://api.github.com/repos/${entry.owner}/${entry.repo}/commits?per_page=3`,
    { headers: { Authorization: `Bearer ${process.env.GITHUB_TOKEN}` } }
  );
  const commits = await res.json();
  const newSha = commits[0]?.sha;

  if (!newSha || newSha === entry.lastSeenSha) return null;

  const commitMessages = commits
    .slice(0, 3)
    .map(c => `- ${c.commit.message.split('\n')[0]}`)
    .join('\n');

  const msg = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 600,
    system: `You are an intelligence analyst. Analyze GitHub commits and explain their impact for Vikash
(FinTech COO at Redpin Payments, NIFTY options trader, AI SaaS builder).
Return JSON only: { impact_title, vikash_impact, action, urgency, dimension }`,
    messages: [{
      role: 'user',
      content: `Repo: ${entry.owner}/${entry.repo}\nNew commits:\n${commitMessages}\nVikash use case: ${entry.vikash_use_case || ''}`
    }]
  });

  return {
    sha: newSha,
    timestamp: Date.now(),
    repo: `${entry.owner}/${entry.repo}`,
    ...JSON.parse(msg.content[0].text)
  };
}

async function main() {
  const kb = JSON.parse(fs.readFileSync(KB_PATH, 'utf8'));
  const log = JSON.parse(fs.existsSync(LOG_PATH) ? fs.readFileSync(LOG_PATH, 'utf8') : '[]');

  for (const entry of kb) {
    const result = await pollRepo(entry);
    if (result) {
      entry.lastSeenSha = result.sha;
      entry.latestImpact = result;
      log.push(result);
      console.log(`Change detected: ${entry.owner}/${entry.repo}`);
    }
  }

  fs.writeFileSync(KB_PATH, JSON.stringify(kb, null, 2));
  fs.writeFileSync(LOG_PATH, JSON.stringify(log, null, 2));
}

main().catch(console.error);
```

---

## Claude Code Session Rules

1. **Always read this file first** — don't assume context
2. **Design system is fixed** — do not introduce new fonts or color schemes
3. **Scoring dimensions are canonical** — do not rename or reorder them
4. **Impact briefings must be personalized** — always reference Vikash's specific context (Redpin, NIFTY, Reel IQ)
5. **Before any UI change** — take a screenshot to verify current state
6. **After any change** — run `npm run dev`, screenshot, confirm, then commit
7. **Secrets** — never hardcode API keys; always use `process.env` or GitHub Secrets
8. **Deploy target** — Vercel (primary), GitHub Pages (static fallback)

---

## Quick Commands

```bash
npm run dev          # Start local dev server
npm run build        # Production build
node scripts/poll.js # Direct poller run (needs ANTHROPIC_API_KEY + GITHUB_TOKEN env vars)
```

---

## Knowledge Base Schema (docs/knowledge-base/repos.json)

```json
[
  {
    "owner": "string",
    "repo": "string",
    "lastSeenSha": "string",
    "analysis": {
      "fintech": 0,
      "dev": 0,
      "trading": 0,
      "marketing": 0,
      "headline": "string",
      "vikash_use_case": "string",
      "watch_reason": "string",
      "tags": []
    },
    "latestImpact": {
      "impact_title": "string",
      "vikash_impact": "string",
      "action": "string",
      "urgency": "high|medium|low",
      "dimension": "fintech|dev|trading|marketing"
    }
  }
]
```

---

*Last updated: auto-generated by GitHub Intel Station export tab*
*Next session: paste updated repos.json content here for fresh context*
